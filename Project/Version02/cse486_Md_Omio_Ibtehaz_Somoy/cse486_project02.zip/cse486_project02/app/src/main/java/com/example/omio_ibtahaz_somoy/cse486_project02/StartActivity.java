package com.example.omio_ibtahaz_somoy.cse486_project02;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class StartActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        EditText student_id = findViewById(R.id.editText_student_id);
        EditText student_email = findViewById(R.id.editText_student_email);
        Spinner selectUniversity = findViewById(R.id.spinner_select_uni);
        Spinner selectDepartment = findViewById(R.id.spinner_select_dept);
        Spinner selectDegree = findViewById(R.id.spinner_select_degree);

        ArrayAdapter<CharSequence> adapter_uni = ArrayAdapter.createFromResource
                (this, R.array.uni, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adapter_dept = ArrayAdapter.createFromResource
                (this, R.array.dept, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adapter_degree = ArrayAdapter.createFromResource
                (this, R.array.degree, android.R.layout.simple_spinner_item);

        adapter_uni.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter_dept.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter_degree.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        selectUniversity.setAdapter(adapter_uni);
        selectDepartment.setAdapter(adapter_dept);
        selectDegree.setAdapter(adapter_degree);

        selectUniversity.setOnItemSelectedListener(this);
        selectDepartment.setOnItemSelectedListener(this);
        selectDegree.setOnItemSelectedListener(this);

        String id = student_id.getText().toString();
        String email = student_email.getText().toString();

        Button next = findViewById(R.id.button_next);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent_startActivity = new Intent(StartActivity.this,StartActivity2.class);
                intent_startActivity.putExtra("id",id);
                intent_startActivity.putExtra("email",email);
                //intent_startActivity.putExtra("uni", (Parcelable) selectUniversity);
                startActivity(intent_startActivity);

            }
        });

    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        String text = parent.getItemAtPosition(position).toString();

       /* Button next = findViewById(R.id.button_next);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_startActivity = new Intent(StartActivity.this,StartActivity2.class);
                intent_startActivity.putExtra("text",text);
            }
        });*/

        Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

}
