package com.example.omio_ibtahaz_somoy.cse486_project02;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class StartActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start2);
        Intent intent_startActivity = getIntent();
        String ID = intent_startActivity.getStringExtra("id");
        String Email = intent_startActivity.getStringExtra("email");
        //String Text = intent_startActivity.getStringExtra("uni");

        TextView show_info = findViewById(R.id.textView_information);
        show_info.setText("Student ID :"+ID+"\nStudent Email :"+Email+"\nUniversity details :");
    }
}